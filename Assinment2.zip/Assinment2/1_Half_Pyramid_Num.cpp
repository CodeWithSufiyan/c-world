#include <iostream>

using namespace std;

int main()
{
    for(int r=1; r<=5; r++){
        for(int c=1; c<=r; c++){
            cout<<c<<"  ";
        }
        cout<<"\n\n";
    }
    return 0;
}