#include <iostream>

using namespace std;

int main()
{
    for(int r=1; r<=5; r++){
        for(int t=4; t>=r; t--){
            cout<<"\t";
        }
        for(int c=1; c<=r; c++){

            cout<<"\t\t"<<'c';
        }
        cout<<"\n\n";
    }
    return 0;
}